﻿namespace My_Office_Tool.ViewModel
{
    class MainViewModel : BaseViewModel
    {
        public string LogText
        {
            get => Get<string>(nameof(LogText), "");
            set => Set<string>(nameof(LogText), value);
        }

        public MainViewModel()
        {

        }
    }
}
