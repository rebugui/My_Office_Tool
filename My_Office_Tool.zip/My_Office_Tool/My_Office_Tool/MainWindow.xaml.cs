﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace My_Office_Tool
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void encoding(object sender, RoutedEventArgs e)
        {
            if (base64_RadioButton.IsChecked == true)
            {
                // 문자열을 유니코드 인코딩으로 바이트배열로 변환
                byte[] bytes = Encoding.Unicode.GetBytes(Input_Text.Text);

                // 바이트들을 Base64로 변환
                string base64_encoding = Convert.ToBase64String(bytes);

                Output_Text.Text = base64_encoding;
            }
            else if (url_RadioButton.IsChecked == true)
            {
                string Url_encoding = HttpUtility.UrlEncode(Input_Text.Text);

                Output_Text.Text = Url_encoding;
            }
            else if (ASCII_to_hex_RadioButton.IsChecked == true)
            {
                string resultHex = string.Empty;
                byte[] arr_byteStr = Encoding.Default.GetBytes(Input_Text.Text);

                foreach (byte byteStr in arr_byteStr)
                    resultHex += (string.Format("{0:X2}", byteStr) + " ");

                Output_Text.Text = resultHex;
            }
            else
            {

            }
        }

        private void decoding(object sender, RoutedEventArgs e)
        {
            if (base64_RadioButton.IsChecked == true)
            {
                // Base64 인코드된 문자열을 바이트배열로 변환
                byte[] orgBytes = Convert.FromBase64String(Input_Text.Text);

                // 바이트들을 다시 유니코드 문자열로
                string base64_decoding = Encoding.Unicode.GetString(orgBytes);

                // 출력: John 굿모닝
                Output_Text.Text = base64_decoding;
            }
            else if (url_RadioButton.IsChecked == true)
            {
                string Url_decoding = HttpUtility.UrlDecode(Input_Text.Text);

                Output_Text.Text = Url_decoding;
            }
            else if (ASCII_to_hex_RadioButton.IsChecked == true)
            {
                Output_Text.Text = "";
                string[] hexValuesSplit = Input_Text.Text.Split(' ');
                foreach (String hex in hexValuesSplit)
                {
                    int value = Convert.ToInt32(hex, 16);
                    string stringValue = char.ConvertFromUtf32(value);
                    Output_Text.AppendText(stringValue);
                }
            }
            else
            {

            }
        }
    }


}
